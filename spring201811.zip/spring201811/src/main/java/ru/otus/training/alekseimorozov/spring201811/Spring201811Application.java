package ru.otus.training.alekseimorozov.spring201811;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring201811Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring201811Application.class, args);
	}

}

